import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
    <h1>Angular Binding 101</h1>
    <hr>
    <h1> Intropulation </h1>
    <h2>1 {{ title }}</h2>
    <hr>
    <h1> Attribute Binding </h1>
    <h2 innerHTML="2 {{ title }}"></h2>
    <h2 textContent="3 {{ title }}"></h2>
    <h2 innerText="4 {{ title }}"></h2>
    <h2 [innerHTML]="'5 '+title"></h2>
    <h2 bind-innerHTML="'6 '+title"></h2>
    <hr>
    <br>
    <input #ti2 type="text" [value]="title" (input)="title = ti2.value">
    <h1>Value Binding</h1>
    <input value="{{ title }}" type="text">
    <br/>
    <input [value]="title" type="text">
    <br/>
    <input bind-value="title" type="text">
    <h1>Style Binding</h1>
    <div style="height : 200px; border : {{ styleProp }}"></div>
    <h1>Class Binding</h1>
    <div class="{{ className }}"></div>
    <br>
    <h1>Property Binding</h1>
    <button [disabled]="agree" >Click Me</button>
    <br>
    <input type="checkbox" [checked]="agree" />
    <br>
    <button (click)="clickHandler()"> Click Me | event Binding </button>
    <br>
    <input (change)="agree = !agree" type="checkbox" />
    <br>
    <button on-click="clickHandler()"> Click Me | event Binding </button>
    <br>
    <br>
    <input #ti type="text">
    <output #op >hello from output</output>
    <button on-click="messageHandler( op.innerHTML )"> Click Me | event Binding </button>
    <br>
    <br>
  `,
  styles : [`
   .box{
      width : 200px;
      height : 200px;
      background-color : grey;
   }
  `]
})
export class AppComponent {
  title:string = 'Text Binding';
  styleProp:string = "2px solid red";
  className:string = "box";
  agree:boolean = false;

  clickHandler(){
    alert("you clicked me");
  };
  messageHandler(message){
    // alert(message);
    this.title = message;
  };
}  
