import { Component } from '@angular/core';
import { UsersService } from './users.service';

@Component({
  selector: 'app-root',
  providers :[UsersService],
  template : `
  <h1>External Users Data</h1>

  <ul class="nav justify-content-center">
    <li  class="nav-item" *ngFor="let user of userdata">
      <a class="nav-link active"  href="#">{{ user.username }}</a>
    </li>
  </ul>

  <hr>


  <div *ngFor="let user of userdata" style="width: 18rem; float : left; margin : 10px" class="card text-center">
  <div class="card-header">
    {{ user.name }}
  </div>
  <div class="card-body">
    <h5 class="card-title">{{ user.username }}</h5>
    <p class="card-text"> Email : {{ user.email }}</p>
    <p class="card-text"> City : {{ user.address.city }}</p>
    <p class="card-text"> Phone : {{ user.phone }}</p>
    <a href="http://{{ user.website }}" class="btn btn-primary">{{ user.website }}</a>
  </div>
  <div class="card-footer text-muted">
    {{ user.company.name }}
  </div>
</div>
  `
})
export class AppComponent {
  title = 'step4-using-data';
  userdata;

  constructor(private us:UsersService){
    this.us.getUsersData().subscribe((res) => {
      this.userdata = res;
    });
  }

}
