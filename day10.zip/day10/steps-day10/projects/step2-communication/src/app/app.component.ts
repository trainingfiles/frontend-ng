import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
    <h1>Component Communication</h1>
    <h2>Application Title : {{ title }}</h2>
    <hr>
    <!--app-child>{{ title }}</app-child-->
    <input [value]="power" (input)="power = $event.target.value" type="range"> Power is :  {{ power }}
    <app-child (childEvent)="childEventHandler($event)" apptitle="{{ power }}">
      <h1>App Title</h1>
      <ul>
        <li>List Item 1</li>
        <li>List Item 2</li>
        <li>List Item 3</li>
        <li>List Item 4</li>
        <li>List Item 5</li>
      </ul>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error ea expedita necessitatibus non ullam obcaecati architecto atque esse consectetur exercitationem, deserunt, maxime sapiente nostrum enim modi voluptatem numquam maiores ex.
      </p>
      <p id="player">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error ea expedita necessitatibus non ullam obcaecati architecto atque esse consectetur exercitationem, deserunt, maxime sapiente nostrum enim modi voluptatem numquam maiores ex.
      </p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error ea expedita necessitatibus non ullam obcaecati architecto atque esse consectetur exercitationem, deserunt, maxime sapiente nostrum enim modi voluptatem numquam maiores ex.
      </p>
      <button>Click Me</button>
      <button class="box">Click Me with class</button>
    </app-child>
  `
})
export class AppComponent {
  title = 'communication example';
  power = 0;
  childEventHandler(evt){
    // alert(evt);
    this.title = evt;
  }
}
