import { Component, EventEmitter, Input, Output } from "@angular/core";


@Component({
    selector : "app-child",
    providers : [],
    inputs : ['apptitle'],
    outputs:['childEvent'],
    template : `
        <h1>Child Component</h1>
        <ng-content select="button:not(.box)"></ng-content>
        <hr>
        <ng-content select="[id=player]"></ng-content>
        <hr>
        <ng-content select="ul"></ng-content>
        <hr>
        <ng-content></ng-content>
        <hr>
        <h2>Title value is : {{ apptitle }}</h2>
        <input #ti (keydown.alt)="clickHandler(ti.value)" type="text">
        <button (click)="clickHandler(ti.value)">Click Me To Broadcast Message to Parent</button>
        `
})
export class ChildComp{
    apptitle = 0;
    childEvent:EventEmitter<any> = new EventEmitter();
    clickHandler(message){
       //  alert("click happened");
       this.childEvent.emit(message);
    }
}