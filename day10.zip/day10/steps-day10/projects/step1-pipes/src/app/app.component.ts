import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
    <h1>Hello Everyone</h1>
    <!--img src="{{ imgsrc }}" alt="">
    <img [src]="imgsrc" alt=""-->

    <ul>
      <li *ngFor="let hero of heroes">{{ hero.title }}</li>
    </ul>
    <table class="table table-striped table-sm table-responsive">
      <thead class="table-dark">
        <tr>
          <th>Sl #</th>
          <th>Title</th>
          <th>Poster</th>
          <th>Full Name</th>
          <th>City</th>
          <th>Ticket Price</th>
          <th>Release Date</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let hero of heroes">
          <td>{{ hero.sl }}</td>
          <td>{{ hero.title | uppercase | gen : hero.gender }}</td>
          <td>
            <img width="40" src="{{ hero.poster }}" alt="{{ hero.title }}">
          </td>
          <td>{{ hero.firstname+" "+hero.lastname | lowercase | uppercase | titlecase }}</td>
          <td>{{ hero.city | slice : 0 : 3 | uppercase }}</td>
          <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '3.3-4' }}</td>
          <td>{{ hero.releasedate | date : 'dd/MMM/yyyy' }}</td>
        </tr>
      </tbody>
    </table>
    </div>
  `,
})
export class AppComponent {
  title = 'step1-pipes';
  imgsrc = 'assets/images/rajani.jpg';
  heroes = [
    {
      sl: 1,
      title: 'Batman',
      gender: 'male',
      firstname: 'Bruce',
      lastname: 'Wayne',
      city: 'Gotham',
      ticketprice: 123.4509434587,
      releasedate: '1/26/2021',
      poster: 'assets/images/batman.jpg',
    },
    {
      sl: 2,
      title: 'Superman',
      gender: 'male',
      firstname: 'Clark',
      lastname: 'Kent',
      city: 'Metropolis',
      ticketprice: 178,
      releasedate: '1/27/2021',
      poster: 'assets/images/superman.jpg',
    },
    {
      sl: 3,
      title: 'Ironman',
      gender: 'male',
      firstname: 'Tony',
      lastname: 'Stark',
      city: 'New York',
      ticketprice: 122.9876543,
      releasedate: '1/27/2021',
      poster: 'assets/images/ironman.jpg',
    },
    {
      sl: 4,
      title: 'Phantom',
      gender: 'male',
      firstname: 'Kit',
      lastname: 'Walker',
      city: 'Bhangala',
      ticketprice: 98.64,
      releasedate: '1/27/2021',
      poster: 'assets/images/phantom.jpg',
    },
    {
      sl: 5,
      title: 'Spiderman',
      gender: 'male',
      firstname: 'Peter',
      lastname: 'Parker',
      city: 'New York',
      ticketprice: 451.34,
      releasedate: '9/26/2021',
      poster: 'assets/images/spiderman.jpg',
    },
    {
      sl: 6,
      title: 'Wonder Women',
      gender: 'female',
      firstname: 'Princess',
      lastname: 'Diana',
      city: 'Amazon',
      ticketprice: 341.34,
      releasedate: '11/26/2021',
      poster: 'assets/images/wonderwoman.png',
    },
  ];
}
