import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : 'gen'
})
export class GenPipe implements PipeTransform{
    transform(...arg):string{
        if(arg[1] === 'male'){
            return "Mr "+arg[0]
        }else{
            return "Miss "+arg[0]
        }
        
    }
}