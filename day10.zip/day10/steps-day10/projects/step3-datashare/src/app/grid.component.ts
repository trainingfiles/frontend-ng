import { Component, Input } from "@angular/core";
import { HeroService } from "./hero.service";

@Component({
    selector : 'app-grid',
    template : `
    <h1> Version is : {{ ver }}</h1>
    <input type="text" (change)="heroes[0].title = $event.target.value">
    <table class="table table-striped table-sm table-responsive">
      <thead class="table-dark">
        <tr>
          <th>Sl #</th>
          <th>Title</th>
          <th>Poster</th>
          <th>Full Name</th>
          <th>City</th>
          <th>Ticket Price</th>
          <th>Release Date</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let hero of heroes">
          <td>{{ hero.sl }}</td>
          <td>{{ hero.title | uppercase }}</td>
          <td>
            <img width="40" src="{{ hero.poster }}" alt="{{ hero.title }}">
          </td>
          <td>{{ hero.firstname+" "+hero.lastname | lowercase | uppercase | titlecase }}</td>
          <td>{{ hero.city | slice : 0 : 3 | uppercase }}</td>
          <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '3.3-4' }}</td>
          <td>{{ hero.releasedate | date : 'dd/MMM/yyyy' }}</td>
        </tr>
      </tbody>
    </table>
    `
})
export class GridComp{
    heroes = [];
    ver = 0 ;
    // hs:HeroService = new HeroService();
    constructor(private hs:HeroService){
      this.heroes = this.hs.getData();
      this.ver = this.hs.getVersion();
    }
}