import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { GridComp } from './grid.component';
import { HeaderComp } from './header.component';
import { HeroService } from './hero.service';

@NgModule({
  declarations: [
    AppComponent, HeaderComp, GridComp
  ],
  imports: [
    BrowserModule
  ],
  providers: [ HeroService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
