import { Component } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
  template : `
  <h1>Heroes Application</h1>
  <app-header></app-header>
  <hr>
  <app-grid></app-grid>
  `
})
export class AppComponent {

  heroes = [];
  hs:HeroService = new HeroService();
  constructor(){
    this.heroes = this.hs.getData();
  }
}
