import { Component, Input } from "@angular/core";
import { HeroService } from "./hero.service";

@Component({
    selector : 'app-header',
    template : `
    <h1> Version is : {{ ver }}</h1>
    <input type="text" (change)="heroes[0].title = $event.target.value">
    <ul class="nav justify-content-center">
        <li class="nav-item" *ngFor="let hero of heroes">
            <a href="#" class="nav-link">{{ hero.title }}</a>
        </li>
    </ul>
    `
})
export class HeaderComp{
    heroes = [];
    ver = 0 ;
    // hs:HeroService = new HeroService();
    constructor(private hs:HeroService ){
      this.heroes = this.hs.getData();
      this.ver = this.hs.getVersion();
    }
}