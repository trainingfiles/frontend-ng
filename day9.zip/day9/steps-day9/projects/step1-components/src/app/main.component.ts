import { Component } from "@angular/core";

@Component({
    selector : "app-main",
    template : `
        <div class="box">
        <h1>Main Component</h1>
        <hr>
        <app-article></app-article>
        <app-article></app-article>
        </div>
    `,
    styles : [`
        .box{
            background-color : orange;
            padding : 10px
        }
    `]
})
export class MainComp{

}