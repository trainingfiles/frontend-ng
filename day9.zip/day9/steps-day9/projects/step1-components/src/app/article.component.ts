import { Component } from "@angular/core";

@Component({
    selector : "app-article",
    template : `
    <div class="box">
        <h2>Article Heading</h2>
        <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum eveniet dolor, dicta dolorem sequi quas quidem, nulla ea quae debitis repudiandae quod eos ullam, molestiae provident expedita voluptatum fugiat sit?
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum eveniet dolor, dicta dolorem sequi quas quidem, nulla ea quae debitis repudiandae quod eos ullam, molestiae provident expedita voluptatum fugiat sit?
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum eveniet dolor, dicta dolorem sequi quas quidem, nulla ea quae debitis repudiandae quod eos ullam, molestiae provident expedita voluptatum fugiat sit?
        </p>
    </div>
    `,styles : [`
    
    .box{
        background-color : #f4f070;
        padding : 10px;
        margin : 10px
    }

    `]
})
export class ArticleComp{

}