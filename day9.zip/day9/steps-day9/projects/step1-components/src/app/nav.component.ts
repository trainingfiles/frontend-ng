import { Component } from "@angular/core";

@Component({
    selector : "app-nav",
    template : `
        <div class="box">
            <h1>Navigation Component</h1>
        </div>
    `,
    styles : [`
    .box{
        padding : 10px;
        background-color : yellow;
        margin-bottom : 10px;
    }
`]
})
export class NavComp{

}