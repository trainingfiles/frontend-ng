import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <div class="box">
    <h1>Sub Application | Welcome Page</h1>
    <app-header></app-header>
    <app-nav></app-nav>
    <app-main></app-main>  
  </div>
  `,
  styles: [`
    .box{
      border : 2px dotted black;
      margin : 10px;
      padding : 10px
    }
  `]
})
export class AppComponent {
  title = 'step1-components';
}
