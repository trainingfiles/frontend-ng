import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
    <h1>Using CLI</h1>
  `
})
export class AppComponent {
  title = 'steps-day12';
}
