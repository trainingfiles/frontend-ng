import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <input #ti type="text">
  <button (click)="tasks.push({ work : ti.value, completed : false }); ti.value = ''">Add Task</button>
    <ol>
      <li [ngStyle]="{'text-decoration': task.completed ? 'line-through' : 'none'}" *ngFor="let task of tasks">
        <span *ngIf="!task.remove">
          <input type="checkbox" (change)="task.completed = !task.completed">
          {{ task.work }}
          <button (click)="delTask(task)"> Delete </button>
        </span>
      </li>
    </ol>

  `
})
export class AppComponent {
  title = 'step4-todo';
  tasks = [];
  done = false;
  delTask(tdel){
    this.tasks = this.tasks.filter((v,i,a) => { 
      return v.work !== tdel.work ;
    });
  }
}
