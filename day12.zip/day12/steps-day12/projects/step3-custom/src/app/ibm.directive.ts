import { Directive, ElementRef, Input, OnInit } from "@angular/core";

@Directive({
    // selector : 'ibm'
    // selector : '.ibm'
    selector : '[ibm]'
})
export class IBMdirective implements OnInit{
    //@Input() tagparam;
    @Input() ibm;
    constructor( private elref:ElementRef ){}
    ngOnInit(){
        // this.elref.nativeElement.style = "color: red";
        // this.elref.nativeElement.children[0].innerHTML += this.tagparam;
        // this.elref.nativeElement.style = "color : "+this.tagparam;
        // ex for class directive
        // this.elref.nativeElement.style = "color: red";
        let cols = this.ibm.split(" ");
        this.elref.nativeElement.style = "border : 10px dotted "+cols[0]+"; color : "+cols[1]+"; background-color: "+cols[2];
    }
} 

