import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : 'ibm'
})
export class IBMPipe implements PipeTransform{
    transform(...args){

        /* let firstLetter = args[0][0].toString();
        let restLetters = '';
        for(let i = 1; i < args[0].length; i++){
            restLetters += args[0][i];
        };
        return firstLetter.toUpperCase()+restLetters; */


        return args[0].toUpperCase()//.split("").reverse().join("");
    }
}