import { NgModule } from "@angular/core";
import { IBMdirective } from "./ibm.directive";
import { IBMPipe } from "./ibm.pipe";

@NgModule({
    declarations : [ IBMPipe, IBMdirective ],
    exports : [ IBMdirective, IBMPipe ]
})
export class IBMModule{

}