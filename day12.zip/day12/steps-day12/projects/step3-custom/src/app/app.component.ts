import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <ul>
      <li class="ibmlist" *ngFor="let hero of heroes">{{ hero | ibm }}</li>
    </ul>
    
    <!--ibm tagparam="red">
      <h1>Heading 1</h1>
    </ibm>
    <ibm tagparam="orange">
      <h2>Heading 2</h2>
    </ibm>
    <ibm tagparam="yellow">
      <h3>Heading 3</h3>
    </ibm-->
    <!--h4 class="ibm">Heading 4</h4>
    <h5 class="ibm">Heading 5</h5-->
      <h6 ibm="blue yellow silver" >Heading 6</h6>
      <p ibm="red green pink" >Paragraph 1</p>
  `,
  styles: [`
  .ibmlist:first-letter{
      font-size : 30px
  }
  `]
})
export class AppComponent {
  title = 'step3-custom';
  heroes = ['batman', 'wonder women', 'superman', 'flash', 'aquaman', 'cyborg'];
}
