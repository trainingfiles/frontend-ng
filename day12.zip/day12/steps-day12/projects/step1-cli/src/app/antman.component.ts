import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-antman',
  template: `
  <div class="card" style="width: 18rem;">
  <img src="assets/images/antman.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque sunt beatae culpa. Nostrum molestias est voluptatum vitae veritatis quibusdam, nemo quidem distinctio voluptatem minus odio omnis laborum, dignissimos quod aut.
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque sunt beatae culpa. Nostrum molestias est voluptatum vitae veritatis quibusdam, nemo quidem distinctio voluptatem minus odio omnis laborum, dignissimos quod aut.
    </p>
  </div>
</div>
  `,
  styles: [
  ]
})
export class AntmanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
