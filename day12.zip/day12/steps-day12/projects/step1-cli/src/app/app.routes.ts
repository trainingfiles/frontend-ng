import { Routes } from "@angular/router";
import { AntmanComponent } from "./antman.component";
import { BatmanComponent } from "./batman.component";
import { HomeComponent } from "./home.component";
import { IronmanComponent } from "./ironman.component";
import { NotfoundComponent } from "./notfound.component";

export let routes:Routes = [
    { path : '', component : HomeComponent },
    { path : 'batman', component : BatmanComponent },
    { path : 'ironman', component : IronmanComponent },
    { path : 'ironman/:qty', component : IronmanComponent },
    { path : 'ironman/:qty/:adargs', component : IronmanComponent },
    { path : 'antman', component : AntmanComponent },
    { path : 'hulk', redirectTo: 'ironman' },
    { path : '**', component: NotfoundComponent },
  ];