import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AntmanComponent } from './antman.component';

import { AppComponent } from './app.component';
import { routes } from './app.routes';
import { BatmanComponent } from './batman.component';
import { IronmanComponent } from './ironman.component';
import { NotfoundComponent } from './notfound.component';


@NgModule({
  declarations: [
    AppComponent, BatmanComponent, IronmanComponent, AntmanComponent, NotfoundComponent
  ],
  imports: [ BrowserModule, RouterModule.forRoot(routes) ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
