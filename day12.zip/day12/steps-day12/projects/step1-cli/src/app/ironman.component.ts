import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ironman',
  template: `
  <h1 *ngIf="selectedItems">Quantity sent : {{ selectedItems }}</h1>
  <h1 *ngIf="additionalArgs">Additional Arguments : {{ additionalArgs }}</h1>
  <div class="card" style="width: 18rem;">
  <img src="assets/images/ironman.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque sunt beatae culpa. Nostrum molestias est voluptatum vitae veritatis quibusdam, nemo quidem distinctio voluptatem minus odio omnis laborum, dignissimos quod aut.
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque sunt beatae culpa. Nostrum molestias est voluptatum vitae veritatis quibusdam, nemo quidem distinctio voluptatem minus odio omnis laborum, dignissimos quod aut.
    </p>
  </div>
</div>
  `,
  styles: [
  ]
})
export class IronmanComponent implements OnInit {
  selectedItems;
  additionalArgs;
  constructor( private actRoute:ActivatedRoute) { }

  ngOnInit(): void {
    // this.selectedItems = this.actRoute.snapshot.params.qty;
    this.selectedItems = this.actRoute.snapshot.params['qty'];
    this.additionalArgs = this.actRoute.snapshot.params['adargs'];
  }

}
