import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-batman',
  template: `
  <input [value]="quantity" (input)="quantity = $event.target.value" type="range">
  <button (click)="clickHandler()">Select Quantity</button> Selected Quantity : {{ quantity }}
  <br>
  <a routerLink="/ironman/{{quantity}}">Navigate to Ironman with Quantity </a>
  <hr>
  <div class="card" style="width: 18rem;">
    <img src="assets/images/batman.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <p class="card-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque sunt beatae culpa. Nostrum molestias est voluptatum vitae veritatis quibusdam, nemo quidem distinctio voluptatem minus odio omnis laborum, dignissimos quod aut.
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque sunt beatae culpa. Nostrum molestias est voluptatum vitae veritatis quibusdam, nemo quidem distinctio voluptatem minus odio omnis laborum, dignissimos quod aut.
      </p>
    </div>
  </div>
  `,
  styles: [
  ]
})
export class BatmanComponent implements OnInit {
  quantity = 0;
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  clickHandler(){
    // this.router.navigate(['/ironman',this.quantity]);
    this.router.navigateByUrl('/ironman/'+this.quantity);
  }
}
