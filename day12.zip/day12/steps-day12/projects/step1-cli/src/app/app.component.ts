import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <div class="container">

    <div class="text-center">
      <h1>Heroes Application</h1>
    </div>

    <ul class="nav justify-content-center">
      <li class="nav-item">
        <a class="nav-link" routerLinkActive="selectedLink" [routerLinkActiveOptions]="{ exact : true }" [routerLink]="['']">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" routerLinkActive="selectedLink" [routerLink]="['batman']">Batman</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" routerLinkActive="selectedLink" [routerLink]="['ironman']">Ironman</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" routerLinkActive="selectedLink" [routerLink]="['antman']">Antman</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" [routerLink]="['hulk']">Hulk</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" routerLinkActive="selectedLink"  [routerLink]="['spiderman']">Spiderman</a>
      </li>
    </ul>
    <hr>
    <router-outlet></router-outlet>
  </div>
  `,
  styles : [`
    .selectedLink{
      background-color : crimson;
      color : white
    }
  `]
})
export class AppComponent {
  // heroes = ['antman', 'ironman', 'batman', 'hulk', 'spiderman']
  title = 'steps-day12';
}
