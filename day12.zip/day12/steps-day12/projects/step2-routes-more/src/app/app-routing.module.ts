import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './components/about.component';
import { BooksComponent } from './components/books.component';
import { ContactComponent } from './components/contact.component';
import { DefaultproductComponent } from './components/defaultproduct.component';
import { GadgetsComponent } from './components/gadgets.component';
import { HomeComponent } from './components/home.component';
import { ProductsComponent } from './components/products.component';
import { WatchesComponent } from './components/watches.component';

const routes: Routes = [
  { path : '', component : HomeComponent },
  { path : 'about', component : AboutComponent },
  { path : 'product', component : ProductsComponent, 
  children : [
    { path : '', component : DefaultproductComponent },
    { path : 'books', component : BooksComponent },
    { path : 'gadgets', component : GadgetsComponent },
    { path : 'watches', component : WatchesComponent },
  ] },
  { path : 'contact', component : ContactComponent },
  { path : '**', redirectTo : '' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
