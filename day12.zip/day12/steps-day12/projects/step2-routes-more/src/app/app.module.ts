import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home.component';
import { AboutComponent } from './components/about.component';
import { ProductsComponent } from './components/products.component';
import { GadgetsComponent } from './components/gadgets.component';
import { WatchesComponent } from './components/watches.component';
import { BooksComponent } from './components/books.component';
import { ContactComponent } from './components/contact.component';
import { DefaultproductComponent } from './components/defaultproduct.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ProductsComponent,
    GadgetsComponent,
    WatchesComponent,
    BooksComponent,
    ContactComponent,
    DefaultproductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
