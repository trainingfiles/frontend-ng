import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaultproduct',
  template: `
    <h1>
      Default Product Page !
    </h1>
  `,
  styles: [
  ]
})
export class DefaultproductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
