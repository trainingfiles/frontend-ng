import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  template: `
  <h1> IBM Store Products Page </h1>
  <router-outlet></router-outlet>
  `,
  styles: [
  ]
})
export class ProductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
