import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books',
  template: `
  <h1> Books @ IBM Store </h1>
  `,
  styles: [
  ]
})
export class BooksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
