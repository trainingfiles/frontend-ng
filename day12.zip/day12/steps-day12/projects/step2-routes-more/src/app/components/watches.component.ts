import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-watches',
  template: `  <h1> Watches @ IBM Store </h1>`,
  styles: [
  ]
})
export class WatchesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
