import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gadgets',
  template: `
  <h1> Gadgets @ IBM Store </h1>
  `,
  styles: [
  ]
})
export class GadgetsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
