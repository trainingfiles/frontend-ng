import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class DataService{
    constructor(private http:HttpClient){}
    getHeroList(){
        return this.http.get("http://localhost:6060/");
    }
    postHeroList(data){
        return this.http.post("http://localhost:6060/",data);
    }
}