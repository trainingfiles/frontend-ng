const express = require("express");
const bp = require("body-parser");
const cors = require("cors");
const fs = require("fs");
//-------------------------------------
let app = express();
// app.use(bp.urlencoded());
app.use(bp.json());
app.use(cors());

let herodata = JSON.parse(fs.readFileSync("./data/heroes.json"));;

app.get("/", (req, res) => {
    /* res.render("index.ejs",{
        title : "Welcome to IBM India Heroes Application",
        herolist : herodata.heroes
    }) */
    res.send(herodata.heroes);
})
app.post("/", (req, res) => {
    console.log(req.body);
    herodata.heroes.push(req.body.heroname);
    fs.writeFileSync("./data/heroes.json", JSON.stringify(herodata) );
    res.send(herodata.heroes);
})
app.listen(6060, "localhost", function(error){
    if(error){
        console.log("Error : ", error);
    }else{
        console.log("Server is now live on localhost : 6060");
    }
})