const express = require("express");
let app = express();

app.use("/assets",express.static(__dirname+"/images"));

app.get("/", function(request, response){
   // console.log(request);
   response.sendFile(__dirname+"/index.html");
})
app.get("/about", function(request, response){
   // console.log(request);
   response.sendFile(__dirname+"/about.html");
})
app.get("/product/:qty", function(request, response){
   // console.log(request);
   let params = request.params.qty;
   response.send(`
   <html>
    <head>
        <title>Product Page</title>
    </head>
    <body>
        <h1>Product Page : ${ params }</h1>
    </body>
   </html>
   `);
})
app.get("/contact", function(request, response){
   // console.log(request);
   response.sendFile(__dirname+"/contact.html");
})
app.get("*", function(request, response){
   // console.log(request);
   response.sendFile(__dirname+"/404.html");
})
/* 
app.listen(4040, "localhost", function(error){
    if(error){
        console.log("Error : ", error);
    }else{
        console.log("Server is now live on localhost : 4040")
    }
}) 
*/

let listen = app.listen(5050, function(error){
    if(error){
        console.log("Error : ", error);
    }else{
        // console.log("Server is now live")
        // console.log("Server is now live"+this);
        // console.log("Server is now live : "+this.address().port)
         console.log("Server is now live : "+listen.address().port);
        // console.log( process.env.port );
    }
})