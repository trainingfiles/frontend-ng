const http = require("http");

let server = http.createServer(function(req, res){
    res.writeHead(200, {
        'Content-Type': 'text/html'
    });
    res.write("<h1> Welcome to IBM </h1>");
    res.end();
});

server.listen(1010, "localhost", function(err){
    if(err){
        console.log("Error : ", err);
    }else{
        console.log("Server is now live on localhost : 1010");
    }
});