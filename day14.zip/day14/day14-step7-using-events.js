const Events = require("events").EventEmitter;
let event = new Events();
/* const events = require("events");
let Event = events.EventEmitter;
let event = new Event(); */
event.on("ibmevent", function(){
    console.log("IBM Event Happened");
});
let count = 0;
let si = setInterval(function(){
    if(count < 5){
        count++;
        event.emit("ibmevent");
    }else{
        console.log("called 5 times ");
        clearInterval(si);
    }
}, 1000);
