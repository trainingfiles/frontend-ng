let user = "vijay";
let company = "IBM India";
// module.exports.compname = company;
// module.exports.username = user;
// module.exports = {
//     un : user,
//     cn : company
// }
let heroeslist = ['batman', 'superman', 'flash', 'wonder woman'];
let listen = function(port, host, callback){
    let por = port || 3000;
    let hos = host || "localhost";
    return callback(por, hos);
}
module.exports = function(){
    return {
        un : user,
        cn : company,
        hl : heroeslist,
        listen : listen
    }
}
