const os = require("os");

console.log(os.arch());//
console.log(os.cpus());//
console.log("Free RAM in GB ",os.freemem() / 1073741824 );//
console.log("Total RAM in GB ",os.totalmem() / 1073741824  );//