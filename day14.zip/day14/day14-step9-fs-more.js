const fs = require("fs");
let exists = fs.existsSync("data");

let createfun = function(){
    fs.writeFile("./data/temp.txt", "welcome to your life", "utf-8", function(err){
        if(err){ console.log("Error : ", err);
        }else{ console.log("file inside directory created");  }
    });
}

if(exists){ createfun();
}else{ fs.mkdirSync("data"); createfun(); }
console.log("directory created");
