const http = require("http");

let server = http.createServer(function(req, res){
    res.writeHead(200, {
        'Content-Type': 'text/html'
    });
    if(req.url === "/"){
        res.write("<h1> Welcome to IBM </h1>");
    }else if(req.url === "/about"){
        res.write("<h1> Welcome to IBM's About </h1>");
    }else if(req.url === "/profile"){
        res.write("<h1> Welcome to your Profile Page </h1>");
    }else if(req.url === "/contact"){
        res.write("<h1> Contact IBM </h1>");
    }else{
        res.writeHead(404, {
            'Content-Type': 'text/html'
        });
        res.write("<h1> 404 : requested page not found </h1>");
    }
    res.end();
});

server.listen(1010, "localhost", function(err){
    if(err){
        console.log("Error : ", err);
    }else{
        console.log("Server is now live on localhost : 1010");
    }
});