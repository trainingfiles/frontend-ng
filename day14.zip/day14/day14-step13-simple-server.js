const http = require("http");
const fs = require("fs");
let config = {
    port : 2020,
    host : "localhost"
};

let server = http.createServer((req, res) => {
    fs.readFile("."+req.url, function(error, data){
        if(data){
            res.writeHead(200, {"Content-Type": "text/html"});
            res.end(data);
        }else if(req.url === '/favicon.ico'){
            res.writeHead(200, {"Content-Type": "image/x-icon"});
            res.end();
        }else{
            res.writeHead(404, {"Content-Type": "text/plain"});
            res.end("404  : Requested page not found ", error);
        }
    })
    // res.end("hello from simple server "+req.url);
})
.listen(config.port, config.host, (err)=>{
    if( err ){ console.log ("Error : ", err )}
    else{ console.log("server is now live on "+config.host+" : "+config.port)};
})