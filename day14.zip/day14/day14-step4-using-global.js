require("./day14-step3-creating-global");

console.log(global.appName);
console.log(global.companyName);