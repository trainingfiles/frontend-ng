let fs = require("fs");
/*
fs.writeFileSync("temp.txt","Welcome to your life","utf-8");
fs.appendFileSync("temp.txt","\nthere's no turning back","utf-8");
let existingText = fs.readFileSync("temp.txt");
// console.log(existingText);
fs.writeFileSync("temp.txt","By \"Bread and Breakfast\" \n"+existingText,"utf-8");
console.log("updating done...");
*/

fs.writeFile("temp.txt","Welcome to your life","utf-8", function(error){
    if(error){
        console.log("Error :", error)
    }else{
        fs.appendFile("temp.txt", "\nthere's no turning back","utf-8", function(error){
            if(error){
                console.log("Error :", error)
            }else{
                let existingText = fs.readFileSync("temp.txt");
                fs.writeFile("temp.txt","By \"Bread and Breakfast\" \n"+existingText,"utf-8", function(error){
                    if(error){
                        console.log("Error :", error)
                    }else{
                        console.log("updating done...");
                    }
                });
            }
        })
    }
});
