let userdata = require("./day14-step1");
let props = userdata();
console.log(props.hl);
let result = props.listen(null, null, function(arg1, arg2){
    return "port : "+arg1+" : host : "+arg2
});
console.log(result);
// console.log(company);