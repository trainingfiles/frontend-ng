global.companyName = "IBM India";
global.appName = "IBM Heroes";