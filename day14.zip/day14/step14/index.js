let app = require("express")();
app.listen(3030,"localhost");
console.log("express is now live on localhost : 3030");