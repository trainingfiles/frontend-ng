let parameters = process.argv[2]+" "+process.argv[3];
console.error(parameters);