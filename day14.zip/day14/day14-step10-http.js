/*
const http = require("http");

let server = http.createServer(function(req, res){
    res.write("Welcome to IBM");
    res.end();
});

server.listen(1010, "localhost", function(err){
    if(err){
        console.log("Error : ", err);
    }else{
        console.log("Server is now live on localhost : 1010");
    }
})

*/

const http = require("http");

let server = http.createServer((req, res) => {
    res.end("<h1> Welcome to IBM </h1>");
}).listen(1010, "localhost", (err) => {
    if(err){ console.log("Error : ", err); }
    else{ console.log("Server is now live on localhost : 1010"); }
})